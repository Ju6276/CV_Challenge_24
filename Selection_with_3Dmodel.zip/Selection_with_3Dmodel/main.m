% Main script
[points, pathName, fileName] = Selection();
if ~isempty(points)
    img = imread(fullfile(pathName, fileName)); % 确保有path和file
    [virtual_output, estimatedVertex] = Build3DModel_new(points, img);
    disp('Estimated Vertex:');
    disp(estimatedVertex);
    Build3DModel_new(points, img);
    subimages = image_mask(img, points);
    transformed_subimages= apply_perspective_transforms(img, points);
    render3DScene(transformed_subimages, estimatedVertex);
end