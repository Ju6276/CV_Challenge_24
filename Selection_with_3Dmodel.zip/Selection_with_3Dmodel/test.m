% 假设的输出尺寸

outH = 300;
outW = 400;
% 假设 input_image 是您从 `image_mask` 获取的左墙图像
%input_image = subimages{1};  % 根据实际存储情况调整索引
input_image = subimages{2};
% 已经定义的左墙角点
corners2 = [
    points(11, :);  % 左上角
    points(7, :);   % 右上角
    points(1, :);   % 右下角
    points(5, :)    % 左下角
];

% 调用透视变换函数
corrected_image = Perspective_transform(input_image, corners2, outH, outW);

% 显示变换后的图像
figure;
imshow(corrected_image);
title('Corrected Perspective of Left Wall');
