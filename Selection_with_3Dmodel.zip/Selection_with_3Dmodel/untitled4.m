function [newH, newW] = adjusted_size(base_size, depth)
    % 调整墙面尺寸基于深度
    % 输入:
    % base_size: 1x2 矩阵，包含最近墙面的高度和宽度
    % depth: 从 0 到 1 的数值，表示墙面的相对深度（0 表示最近，1 表示最远）
    %
    % 输出:
    % newH: 调整后的高度
    % newW: 调整后的宽度

    % 假设更深的墙面尺寸应该减小，这里设置最多减小到50%的基础尺寸
    factor = 1 - depth * 0.5;  % 深度影响因子

    % 计算新的高度和宽度
    newH = round(base_size(1) * factor);
    newW = round(base_size(2) * factor);
end

% 使用示例
base_size = [600, 800];  % 最近墙面的基础高度和宽度
depth = 0.7;             % 某个墙面的深度估计
[newH, newW] = adjusted_size(base_size, depth);